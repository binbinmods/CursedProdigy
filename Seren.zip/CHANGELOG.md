# 0.1.1

Nerfed cursed wand, passive. Buffed Sorcerous Mastery. 

# 0.1.0

Initial pre-release